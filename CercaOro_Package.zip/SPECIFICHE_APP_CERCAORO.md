# SPECIFICHE TECNICHE - CercaOro Pro v3.0

## Panoramica
CercaOro Pro e una Progressive Web App (PWA) per l'esplorazione di 170 luoghi auriferi reali d'Italia e d'Europa (100 IT + 70 EU). Include coordinate GPS, filtri avanzati, mappa interattiva e sistema di licenza a pagamento.

## Struttura
```
CercaOro_Package/
|-- index.html              # App PWA principale
|-- manifest.json           # Configurazione PWA
|-- css/style.css           # Stili completi
|-- js/app.js               # Logica JavaScript
|-- gold_locations.json     # Database (170 siti reali)
|-- luoghi_auriferi_italia.csv
|-- luoghi_auriferi_europa.csv
|-- mappa_oro_italia.jpg    # Mappa visiva
|-- database_tabelle.jpg    # Dashboard statistiche
|-- SPECIFICHE_APP_CERCAORO.md
```

## Database
- **Italia**: 100 siti (65 torrenti auriferi + 35 filoni primari)
- **Europa**: 70 siti (38 torrenti + 32 filoni primari)
- **Coordinate**: basate sui comuni attraversati dai torrenti auriferi documentati
- **Qualita Alta**: 47 siti | **Media**: 32 | **Bassa**: 91

## Licenza
- Mensile: EUR 4.99 (~4.20 netto)
- Annuale: EUR 29.99 (~25.50 netto)
- Prova gratuita: 7 giorni
- Codice demo: ORO2026

## Dipendenze CDN
- Leaflet 1.9.4 (mappa)
- Font Awesome 6.4.0 (icone)
- CARTO Dark Matter (tiles)

## Compatibilita
Chrome 90+, Firefox 88+, Safari 14+, Edge 90+
